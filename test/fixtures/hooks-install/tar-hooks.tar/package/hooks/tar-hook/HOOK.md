---
metadata: '{"remoteclaw":{"events":["command:new"]}}'
---
# Tar Hook
