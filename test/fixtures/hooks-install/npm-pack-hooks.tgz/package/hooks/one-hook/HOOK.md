---
name: one-hook
description: One hook
metadata: '{"remoteclaw":{"events":["command:new"]}}'
---

# One Hook
