---
metadata: '{"remoteclaw":{"events":["command:new"]}}'
---
# Zip Hook
